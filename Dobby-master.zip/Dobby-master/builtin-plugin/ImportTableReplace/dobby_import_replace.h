#pragma once

#ifdef __cplusplus
extern "C" {
#endif

// int DobbyImportTableReplace(char *image_name, char *symbol_name, void *fake_func, void **orig_func);

#ifdef __cplusplus
}
#endif
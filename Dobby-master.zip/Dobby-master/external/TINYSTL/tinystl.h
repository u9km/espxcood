#pragma once

#include "new.h"
#include "vector.h"

namespace stl = tinystl;
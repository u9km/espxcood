#include "platform_detect_macro.h"
#if defined(TARGET_ARCH_X64)

#include "core/assembler/assembler-x64.h"

using namespace zz::x64;

#endif
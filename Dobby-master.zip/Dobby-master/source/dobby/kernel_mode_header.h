#pragma once

#include <mach/mach_types.h>
#include <mach/mach_vm.h>
#include <vm/vm_kern.h>
#include <libkern/libkern.h>
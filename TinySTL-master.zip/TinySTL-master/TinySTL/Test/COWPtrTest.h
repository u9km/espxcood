#ifndef _COWPTR_TEST_H_
#define _COWPTR_TEST_H_

#include "../COWPtr.h"

#include <cassert>

namespace TinySTL{
	namespace COWPtrTest{
		void testCase1();

		void testAllCases();
	}
}

#endif
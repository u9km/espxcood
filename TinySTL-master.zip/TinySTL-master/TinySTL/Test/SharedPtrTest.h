#ifndef _SHARED_PTR_TEST_H_
#define _SHARED_PTR_TEST_H_

#include "../Memory.h"

#include <cassert>

namespace TinySTL{
	namespace SharedPtrTest{
		void testCase1();

		void testAllCases();
	}
}

#endif
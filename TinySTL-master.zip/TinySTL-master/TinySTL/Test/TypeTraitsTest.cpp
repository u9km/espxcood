#include "TypeTraitsTest.h"
#include <cassert>

namespace TinySTL{
	namespace TypeTraitsTest{
		void testCase1(){
		}

		void testAllCases(){
			testCase1();
		}
	}
}
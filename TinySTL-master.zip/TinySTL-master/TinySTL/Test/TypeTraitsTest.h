#ifndef _TYPE_TRAITS_TEST_H_
#define _TYPE_TRAITS_TEST_H_

#include "../TypeTraits.h"

namespace TinySTL{
	namespace TypeTraitsTest{
		void testAllCases();
	}
}

#endif
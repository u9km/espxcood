#ifndef _UF_SET_TEST_H_
#define _UF_SET_TEST_H_

#include "../UFSet.h"
#include <cassert>

namespace TinySTL{
	namespace UFSetTest{
		void testCase1();

		void testAllCases();
	}
}

#endif